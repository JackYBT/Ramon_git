# Overview
Example code for Cortex V2. So far we have the following languages:
* C++ (with Qt library https://www.qt.io)
* C#
* NodeJS
* Python
* Unity

# API Documentation
For Cortex V2 API documentations please check out: https://emotiv.gitbook.io/cortex-api/
