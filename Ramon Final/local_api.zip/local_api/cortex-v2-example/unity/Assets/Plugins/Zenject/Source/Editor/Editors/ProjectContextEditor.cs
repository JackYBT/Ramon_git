using UnityEditor;

namespace Zenject
{
    [CustomEditor(typeof(ProjectContext))]
    public class ProjectContextEditor : ContextEditor
    {
    }
}
