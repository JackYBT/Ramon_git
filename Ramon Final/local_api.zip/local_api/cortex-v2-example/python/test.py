import numpy as np
from cortex import Cortex

user = {'license': 'a718b5f2-3470-4a0c-9862-0420ff78434b',
		'client_id': 'r9P9TKzrQ0bSpbNhO9eRGbFsHDS8w6ug1bYXRF34', 
		'client_secret': 'FhoWv8IRoiMIfkZapaHsVUTGvoExbeCNBMoSwfEcSk9KaLehjc7RqYxcnBBwwveOsRyWY9OJsHdrL4I1OUEU3AmkWwgGJjKYYQfYrArceo6VXI328PwZMshOw24cEm6c',
		'debit': 100}

c = Cortex(user, debug_mode=True)
c.do_prepare_steps()